#include "testlib.h"
#include <iostream>
using namespace std;
 
int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int n=atoi(argv[1]);
    string s="";
    for(int i=0; i<n; i++) {
        int x=rnd.next(4);
        if(x==0) s+="A";
        else if(x==1) s+="T";
        else if(x==2) s+="C";
        else s+="G";
    }
    cout << n << "\n" << s << "\n";
}