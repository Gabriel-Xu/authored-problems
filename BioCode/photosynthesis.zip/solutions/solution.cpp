#include <bits/stdc++.h>
using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    a=min(a, b)/6;
    cout << a << " " << 6*a << "\n";
}