#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    string s;
    cin >> n >> s;
    string ans="";
    for(int i=0; i<n; i++) {
        if(s[i]=='A') ans+='U';
        else if(s[i]=='T') ans+='A';
        else if(s[i]=='C') ans+='G';
        else ans+='C';
    }
    cout << ans << "\n";
}